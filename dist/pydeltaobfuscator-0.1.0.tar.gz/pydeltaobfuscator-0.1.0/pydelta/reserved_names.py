class Reserved:
    reserved_init_names = [
        "__init__",
        "__del__",
        "__repr__",
        "__str__",
        "__len__",
        "__getitem__",
        "__setitem__",
        "__delitem__",
        "__iter__",
        "__next__",
        "__call__",
    ]