from .PyDelta import delta_obfuscate
from .PyDelta import obfuscate_cli